package com.example.lyla

import android.content.Context
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object ClaudeApi {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    fun ask(context: Context, systemPrompt: String, userText: String): String {
        val prefs = context.getSharedPreferences("lyla_prefs", Context.MODE_PRIVATE)
        val apiKey = prefs.getString("api_key", "") ?: ""

        if (apiKey.isBlank()) {
            return "Ключ API не задан. Открой приложение и вставь его на главном экране."
        }

        val payload = JSONObject().apply {
            put("model", "claude-sonnet-4-6")
            put("max_tokens", 500)
            put("system", systemPrompt)
            put("messages", JSONArray().put(
                JSONObject().put("role", "user").put("content", userText)
            ))
        }

        val request = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .addHeader("x-api-key", apiKey)
            .addHeader("anthropic-version", "2023-06-01")
            .addHeader("content-type", "application/json")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val responseBody = response.body?.string() ?: return "Пустой ответ сервера."
            if (!response.isSuccessful) {
                return "Ошибка API (код ${response.code}). Проверь ключ и баланс аккаунта."
            }
            val json = JSONObject(responseBody)
            val content = json.getJSONArray("content")
            for (i in 0 until content.length()) {
                val block = content.getJSONObject(i)
                if (block.optString("type") == "text") {
                    return block.getString("text")
                }
            }
            return "Не удалось разобрать ответ."
        }
    }
}
