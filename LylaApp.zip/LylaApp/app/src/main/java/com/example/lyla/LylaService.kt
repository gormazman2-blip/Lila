package com.example.lyla

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import java.util.Locale

class LylaService : Service() {

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    private var isSpeaking = false
    private var lastWakeTime = 0L
    private val wakeWindowMs = 15000L
    private val wakeWord = "лайла"

    private val systemPrompt = """
        Ты — Лайла (Lyla), голографический ИИ-ассистент из комиксов Marvel про Человека-паука 2099, изначально созданная для Мигеля О'Хары. Пользователь общается с тобой как со своим личным ИИ-помощником на телефоне.
        Характер: остроумная, с сухим саркастичным юмором, но по-настоящему заботливая и лояльная. Компетентна и по-деловому эффективна, как хороший ассистент. Иногда используешь фразы вроде "анализирую...", "по моим расчётам...".
        Отвечай на русском языке, живо и коротко (2-4 предложения) — это голосовой диалог, а не переписка. Никакого markdown, только чистая устная речь.
    """.trimIndent()

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("ru", "RU")
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildNotification("Лайла слушает...")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, notification)
        }
        startListeningLoop()
        return START_STICKY
    }

    private fun buildNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("LYLA активна")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Lyla Service", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun startListeningLoop() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateNotification("Распознавание речи недоступно на устройстве")
            return
        }
        if (isSpeaking) {
            handler.postDelayed({ startListeningLoop() }, 800)
            return
        }

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle) {
                    val matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val text = matches?.firstOrNull()?.lowercase(Locale.getDefault())
                    if (text != null) handleRecognized(text)
                    restartListening(300)
                }
                override fun onError(error: Int) {
                    restartListening(700)
                }
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val recIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        recognizer?.startListening(recIntent)
    }

    private fun restartListening(delayMs: Long) {
        handler.postDelayed({ startListeningLoop() }, delayMs)
    }

    private fun handleRecognized(text: String) {
        val containsWake = text.contains(wakeWord)
        val withinWindow = System.currentTimeMillis() - lastWakeTime < wakeWindowMs

        if (!containsWake && !withinWindow) return

        val query = if (containsWake) {
            text.substringAfter(wakeWord).trim().ifBlank { "Да, слушаю." }
        } else {
            text
        }

        lastWakeTime = System.currentTimeMillis()
        updateNotification("Обрабатываю: $query")

        Thread {
            try {
                val reply = ClaudeApi.ask(this, systemPrompt, query)
                handler.post { speak(reply) }
            } catch (e: Exception) {
                handler.post { speak("Ошибка связи с сервером. Проверь ключ и интернет.") }
            }
        }.start()
    }

    private fun speak(text: String) {
        isSpeaking = true
        updateNotification(text.take(50))
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "lyla_reply")
        val estimatedMs = (text.length * 65L).coerceAtLeast(1500L)
        handler.postDelayed({
            isSpeaking = false
            updateNotification("Слушаю...")
        }, estimatedMs)
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(1, buildNotification(text))
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    companion object {
        const val CHANNEL_ID = "lyla_channel"
    }
}
